# KoraVote

Static website for football match voting.

Files:
- index.html

Deploy:
1. Upload to GitHub repository.
2. Connect repository to Netlify.
3. Publish directory: leave empty or use /
4. No build command needed.

Supabase tables required:
- matches
- votes
